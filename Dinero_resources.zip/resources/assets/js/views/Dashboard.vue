<template>
    <div>
        <page-header icon="fa-home" title="Инфо. панель"></page-header>

        <div class="container-fluid">
            Инфо.панель
        </div>
    </div>
</template>