<template>
    <div>
        Страниц не найдена
    </div>
</template>