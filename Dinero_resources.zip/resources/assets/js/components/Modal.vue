<template>
    <div class="modal fade" :id="id" tabindex="-1" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title" v-text="title"></h4>
                </div>

                <div class="modal-body">
                    <slot name="modal-body"></slot>
                </div>

                <!-- Modal Actions -->
                <slot name="modal-footer"></slot>
            </div>
        </div>
    </div>
</template>

<script>
  export default {
       /*
         * The component's props.
         */
        props: ['id', 'title'],
    }
</script>