@extends('layouts.app')

@section('content')
    <router-view></router-view>
@endsection